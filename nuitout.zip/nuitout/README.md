# NuitOut — Guide de déploiement

## Structure des fichiers
```
nuitout/
├── index.html        ← Page principale
├── manifest.json     ← Config PWA (icône, nom, couleur)
├── sw.js             ← Service worker (offline + notifs)
├── vercel.json       ← Config Vercel
├── src/
│   ├── style.css     ← Tous les styles
│   └── app.js        ← Toute la logique
└── icons/
    ├── icon-192.png  ← À créer (voir ci-dessous)
    └── icon-512.png  ← À créer (voir ci-dessous)
```

## Étape 1 — Créer les icônes
Va sur https://favicon.io/favicon-generator/
- Texte : "NO" (NuitOut)
- Background : #0d0d1a
- Couleur texte : #b46eff
- Télécharge le ZIP → place icon-192.png et icon-512.png dans le dossier /icons/

## Étape 2 — Créer un compte GitHub (gratuit)
1. Va sur https://github.com
2. Crée un compte
3. Clique "New repository" → nom : "nuitout" → Public → Create
4. Upload tous les fichiers (drag & drop dans l'interface)

## Étape 3 — Déployer sur Vercel (gratuit, 2 minutes)
1. Va sur https://vercel.com
2. "Sign up with GitHub"
3. "Add New Project" → sélectionne ton repo "nuitout"
4. Clique "Deploy" (tout est déjà configuré)
5. Vercel te donne une URL : https://nuitout-tonnom.vercel.app

## Étape 4 — Installer sur ton iPhone
1. Ouvre l'URL dans Safari (pas Chrome !)
2. Appuie sur l'icône Partager (carré avec flèche)
3. "Sur l'écran d'accueil"
4. L'app apparaît comme une vraie app !

## Étape 5 — Partager avec tes potes
Envoie-leur juste le lien Vercel.
Ils font pareil : Safari → Ajouter à l'écran d'accueil.
Aucune installation depuis l'App Store nécessaire.

## Personnaliser les potes
Dans src/app.js, ligne 3 :
```js
const ME = "Alex";  // ← Mets ton prénom
const POTES = ["Alex","Mehdi","Sofia","Lucas","Inès"];  // ← Liste du groupe
```
Chaque pote peut changer ME à son prénom sur sa version.

## Pour la prochaine version
- Base de données partagée → Supabase (gratuit)
- Vraies notifications push → OneSignal (gratuit)
- Auth par téléphone → Supabase Auth
