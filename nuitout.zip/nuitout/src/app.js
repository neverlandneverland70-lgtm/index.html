// ─── CONFIG ────────────────────────────────────────────────────────────────
const ME = "Alex";
const POTES = ["Alex","Mehdi","Sofia","Lucas","Inès"];
const AVC = {Alex:"ag",Mehdi:"ao",Sofia:"ap",Lucas:"ar","Inès":"ap"};
const INI = n => n.slice(0,2).toUpperCase();
const LEVELS = ["Débutant","Social","Festif","Clubber","Légende"];

// ─── STATE (persisté dans localStorage) ───────────────────────────────────
function loadState() {
  try {
    const saved = localStorage.getItem('nuitout_state');
    if (saved) return JSON.parse(saved);
  } catch(e) {}
  return defaultState();
}

function defaultState() {
  return {
    xp: 680,
    streak: 4,
    openEvId: null,
    openDpTab: {},
    selVibe: "Clubbing",
    events: [
      {id:1,name:"Boom Box",date:"2026-03-27",time:"23:00",lieu:"Club O2",vibe:"Clubbing",by:"Mehdi",
       votes:{Alex:"yes",Mehdi:"yes",Sofia:"yes",Lucas:"maybe","Inès":""},
       chat:[{who:"Mehdi",txt:"Les gars c'est gratuit avant minuit !",t:"22:05"},{who:"Sofia",txt:"HYPER chaud, j'amène des potes",t:"22:12"},{who:"Lucas",txt:"Je sais pas encore, j'ai exam samedi matin",t:"22:30"}],
       deps:[{who:"Mehdi",desc:"Tickets entrée x3",amt:30},{who:"Sofia",desc:"Uber retour",amt:18}],
       invites:{Alex:"accepted",Mehdi:"accepted",Sofia:"accepted",Lucas:"sent","Inès":"none"}},
      {id:2,name:"Pré-soirée chez Mehdi",date:"2026-03-27",time:"21:00",lieu:"Chez Mehdi",vibe:"Pré-soirée",by:"Mehdi",
       votes:{Alex:"",Mehdi:"yes",Sofia:"yes",Lucas:"yes","Inès":"yes"},
       chat:[{who:"Inès",txt:"J'apporte la sangria !",t:"18:00"},{who:"Lucas",txt:"J'arrive vers 21h30",t:"19:15"}],
       deps:[{who:"Inès",desc:"Bouteilles sangria",amt:22},{who:"Lucas",desc:"Chips & snacks",amt:12}],
       invites:{Alex:"none",Mehdi:"accepted",Sofia:"accepted",Lucas:"accepted","Inès":"accepted"}},
      {id:3,name:"Bar Le Comptoir",date:"2026-04-05",time:"20:00",lieu:"Le Comptoir",vibe:"Bar",by:"Sofia",
       votes:{Alex:"maybe",Mehdi:"",Sofia:"yes",Lucas:"","Inès":""},
       chat:[{who:"Sofia",txt:"Nouveau bar ouvert près de la fac, ça l'air ouf",t:"14:00"}],
       deps:[],
       invites:{Alex:"sent",Mehdi:"none",Sofia:"accepted",Lucas:"none","Inès":"none"}},
    ],
    notifs: [
      {icon:"🎉",icls:"ni-pur",txt:"<b>Sofia</b> est chaud pour <b>Boom Box</b>",time:"Il y a 5 min",unread:true},
      {icon:"💬",icls:"ni-pur",txt:"<b>Mehdi</b> : \"Gratuit avant minuit !\"",time:"Il y a 22 min",unread:true},
      {icon:"💸",icls:"ni-ora",txt:"<b>Mehdi</b> a ajouté une dépense de <b>30€</b>",time:"Il y a 1h",unread:true},
      {icon:"✉️",icls:"ni-grn",txt:"<b>Lucas</b> a accepté ton invitation",time:"Il y a 2h",unread:false},
    ]
  };
}

let S = loadState();

function save() {
  try { localStorage.setItem('nuitout_state', JSON.stringify(S)); } catch(e) {}
}

// ─── TOAST ─────────────────────────────────────────────────────────────────
function showToast(msg) {
  let t = document.querySelector('.toast');
  if (!t) { t = document.createElement('div'); t.className='toast'; document.body.appendChild(t); }
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2200);
}

// ─── XP ────────────────────────────────────────────────────────────────────
function gainXP(pts) {
  S.xp = Math.min(1000, S.xp + pts);
  const pct = Math.round((S.xp / 1000) * 100);
  const lvl = Math.min(4, Math.floor(S.xp / 200));
  document.getElementById('xp-fill').style.width = pct + '%';
  document.getElementById('xp-label').textContent = S.xp + ' / 1000 XP';
  document.getElementById('xp-level').textContent = 'Niveau ' + (lvl+1) + ' — ' + LEVELS[lvl];
  save();
}

// ─── HEADER ────────────────────────────────────────────────────────────────
function updateHeader() {
  document.getElementById('hd-username').textContent = 'salut, ' + ME;
  document.getElementById('hd-streak').textContent = '⚡ ' + S.streak + ' semaines';
  const next = S.events.find(e => new Date(e.date+'T'+e.time) >= new Date());
  if (next) {
    const yes = Object.values(next.votes).filter(v=>v==="yes").length;
    const dt = new Date(next.date+'T'+next.time);
    const diff = Math.ceil((dt - new Date()) / (1000*60*60*24));
    const when = diff === 0 ? "ce soir" : diff === 1 ? "demain" : `dans ${diff} jours`;
    document.getElementById('hd-msg').textContent = `${next.name} ${when} — ${yes} pote${yes>1?"s":""} chaud${yes>1?"s":""}`;
  } else {
    document.getElementById('hd-msg').textContent = "Pas de soirée prévue — crée-en une !";
  }
  const unread = S.notifs.filter(n=>n.unread).length;
  const dotN = document.getElementById('dot-notifs');
  if (dotN) dotN.classList.toggle('show', unread > 0);
}

// ─── TABS ──────────────────────────────────────────────────────────────────
function goTab(t, btn) {
  ['events','notifs','stats','create'].forEach(id => {
    const el = document.getElementById('tab-'+id);
    if (el) el.style.display = 'none';
  });
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('tab-'+t).style.display = 'block';
  btn.classList.add('active');
  if (t === 'stats') renderStats();
  if (t === 'notifs') renderNotifs();
  if (t === 'events') renderEvents();
}

// ─── VIBE PICKER ───────────────────────────────────────────────────────────
function pickVibe(el) {
  document.querySelectorAll('#vibe-pick .vtag').forEach(t => t.classList.remove('sel'));
  el.classList.add('sel');
  S.selVibe = el.textContent;
}
document.addEventListener('DOMContentLoaded', () => {
  const first = document.querySelector('#vibe-pick .vtag');
  if (first) first.classList.add('sel');
});

// ─── VOTE ──────────────────────────────────────────────────────────────────
function vote(eid, v, e) {
  if (e) e.stopPropagation();
  const ev = S.events.find(x => x.id === eid); if (!ev) return;
  ev.votes[ME] = ev.votes[ME] === v ? "" : v;
  if (ev.votes[ME]) {
    const lbl = v==="yes" ? "est chaud pour" : v==="maybe" ? "est peut-être pour" : "n'est plus dispo pour";
    S.notifs.unshift({icon:"🎉",icls:"ni-pur",txt:`<b>Toi</b> ${lbl} <b>${ev.name}</b>`,time:"À l'instant",unread:false});
    gainXP(v==="yes" ? 30 : 10);
    showToast(v==="yes" ? "Chaud ! +30 XP" : "Peut-être ! +10 XP");
  }
  save(); renderEvents();
}

// ─── OPEN/CLOSE DETAIL ─────────────────────────────────────────────────────
function toggleDetail(eid) {
  S.openEvId = S.openEvId === eid ? null : eid;
  if (S.openEvId && !S.openDpTab[eid]) S.openDpTab[eid] = "chat";
  save(); renderEvents();
}

function setDpTab(eid, tab, e) {
  if (e) e.stopPropagation();
  S.openDpTab[eid] = tab;
  save(); renderEvents();
}

// ─── FORMAT DATE ───────────────────────────────────────────────────────────
function fmtDate(d, t) {
  const days = ["Dim","Lun","Mar","Mer","Jeu","Ven","Sam"];
  const months = ["jan","fév","mar","avr","mai","jun","jul","aoû","sep","oct","nov","déc"];
  const dt = new Date(d+'T'+t);
  return days[dt.getDay()] + ' ' + dt.getDate() + ' ' + months[dt.getMonth()] + ' · ' + t;
}

function avEl(p) {
  return `<div class="av ${AVC[p]||'agr'}">${INI(p)}</div>`;
}

// ─── RENDER EVENTS ─────────────────────────────────────────────────────────
function renderEvents() {
  const list = document.getElementById('ev-list');
  if (!list) return;
  if (!S.events.length) { list.innerHTML = '<div style="text-align:center;padding:2rem;color:var(--text3);font-size:14px">Aucune soirée — crée la première !</div>'; return; }

  let html = '';
  S.events.forEach(ev => {
    const yes = Object.values(ev.votes).filter(v=>v==="yes").length;
    const maybe = Object.values(ev.votes).filter(v=>v==="maybe").length;
    const pct = Math.round((yes / POTES.length) * 100);
    const myV = ev.votes[ME] || "";
    const pill = yes>=4 ? `<span class="pill pill-go">Ça part !</span>` : yes>=2 ? `<span class="pill pill-fire">${yes} chauds</span>` : yes>=1 ? `<span class="pill pill-pur">Tout juste</span>` : `<span class="pill pill-wait">En attente</span>`;
    const hot = yes >= 3 ? " hot" : "";
    const barcol = yes>=4 ? "#b46eff" : yes>=2 ? "#ff8c00" : "#7fff6e";
    const avs = POTES.map(p => {
      const v = ev.votes[p];
      const c = v==="yes"?"ag":v==="no"?"ar":v==="maybe"?"ao":"agr";
      return `<div class="av ${c}" title="${p}">${INI(p)}</div>`;
    }).join('');

    html += `<div class="ecard${hot}" onclick="toggleDetail(${ev.id})">
      <div class="ec-top">
        <div>
          <div class="ec-name">${ev.name} <span style="font-size:11px;font-weight:400;color:var(--text3)">${ev.vibe||''}</span></div>
          <div class="ec-sub">${fmtDate(ev.date,ev.time)} · ${ev.lieu}</div>
        </div>
        ${pill}
      </div>
      <div class="av-row">${avs}<span class="av-ct">${yes} chaud${yes>1?'s':''} · ${maybe} peut-être</span></div>
      <div class="pbar"><div class="pbar-f" style="width:${pct}%;background:${barcol}"></div></div>
      <div class="vote-row">
        <button class="vbtn ${myV==='yes'?'vy':''}" onclick="vote(${ev.id},'yes',event)">Chaud</button>
        <button class="vbtn ${myV==='maybe'?'vm':''}" onclick="vote(${ev.id},'maybe',event)">Peut-être</button>
        <button class="vbtn ${myV==='no'?'vn':''}" onclick="vote(${ev.id},'no',event)">Pas dispo</button>
      </div>
    </div>`;

    if (S.openEvId === ev.id) {
      const tab = S.openDpTab[ev.id] || "chat";
      html += `<div class="detail-panel" onclick="event.stopPropagation()">
        <div class="dp-tabs">
          <button class="dp-tab ${tab==='chat'?'active':''}" onclick="setDpTab(${ev.id},'chat',event)">Chat</button>
          <button class="dp-tab ${tab==='deps'?'active':''}" onclick="setDpTab(${ev.id},'deps',event)">Dépenses</button>
          <button class="dp-tab ${tab==='inv'?'active':''}" onclick="setDpTab(${ev.id},'inv',event)">Invitations</button>
        </div>
        <div class="dp-body">
          ${tab==='chat' ? renderChat(ev) : tab==='deps' ? renderDeps(ev) : renderInv(ev)}
        </div>
      </div>`;
    }
  });
  list.innerHTML = html;
  updateHeader();
}

// ─── CHAT ──────────────────────────────────────────────────────────────────
function renderChat(ev) {
  const msgs = ev.chat.map(m => {
    const isMe = m.who === ME;
    return `<div class="msg ${isMe?'me':''}">
      <div class="msg-av ${AVC[m.who]||'agr'}">${INI(m.who)}</div>
      <div>
        ${!isMe ? `<div class="msg-name">${m.who} · ${m.t}</div>` : ''}
        <div class="msg-bubble ${isMe?'me-b':'them'}">${m.txt}</div>
      </div>
    </div>`;
  }).join('');
  return `<div class="chat-msgs">${msgs}</div>
  <div class="chat-input-row">
    <input class="chat-in" id="cin-${ev.id}" type="text" placeholder="Écris un message..." onkeydown="if(event.key==='Enter')sendMsg(${ev.id})"/>
    <button class="chat-send" onclick="sendMsg(${ev.id})">Envoyer</button>
  </div>`;
}

function sendMsg(eid) {
  const input = document.getElementById('cin-'+eid); if (!input) return;
  const txt = input.value.trim(); if (!txt) return;
  const ev = S.events.find(x => x.id === eid); if (!ev) return;
  const now = new Date();
  const t = now.getHours() + ':' + String(now.getMinutes()).padStart(2,'0');
  ev.chat.push({who: ME, txt, t});
  S.notifs.unshift({icon:"💬",icls:"ni-pur",txt:`<b>Toi</b> dans <b>${ev.name}</b> : "${txt.slice(0,25)}${txt.length>25?'...':''}"`,time:"À l'instant",unread:false});
  gainXP(10);
  input.value = '';
  save(); renderEvents();
}

// ─── DÉPENSES ──────────────────────────────────────────────────────────────
function renderDeps(ev) {
  const total = ev.deps.reduce((s,d) => s+d.amt, 0);
  const present = POTES.filter(p => ev.votes[p]==="yes").length || 1;
  const perHead = Math.round(total / present);
  const myPaid = ev.deps.filter(d=>d.who===ME).reduce((s,d)=>s+d.amt, 0);
  const bal = myPaid - perHead;

  let html = `<div class="dep-total"><span class="dep-total-lbl">Total groupe</span><span class="dep-total-num">${total}€</span></div>`;
  html += ev.deps.map(d => {
    const share = Math.round(d.amt / present);
    return `<div class="dep-item">
      <div class="av ${AVC[d.who]||'agr'}" style="width:24px;height:24px;font-size:9px;margin:0">${INI(d.who)}</div>
      <div class="dep-who">${d.who}</div>
      <div class="dep-desc">${d.desc}</div>
      <div style="text-align:right"><div class="dep-amt">${d.amt}€</div><div class="dep-split">÷${present} = ${share}€</div></div>
    </div>`;
  }).join('');

  if (ev.deps.length) {
    html += `<div class="divhr"></div><div class="balance-row">
      <span style="color:var(--text2);font-size:13px">Ta balance (${ME})</span>
      <span class="${bal>0?'bal-pos':bal<0?'bal-neg':'bal-zero'}">${bal>0?'+':''}${bal}€ ${bal>0?'(on te doit)':bal<0?'(tu dois)':'(égal)'}</span>
    </div>`;
  }

  html += `<div class="dep-add-row">
    <input class="dep-in" id="ddesc-${ev.id}" placeholder="Ex: Uber, cocktails..." style="flex:2"/>
    <input class="dep-in" id="damt-${ev.id}" type="number" placeholder="€" min="0" style="width:60px"/>
    <button class="dep-btn" onclick="addDep(${ev.id})">+</button>
  </div>`;
  return html;
}

function addDep(eid) {
  const desc = document.getElementById('ddesc-'+eid)?.value.trim();
  const amt = parseFloat(document.getElementById('damt-'+eid)?.value);
  if (!desc || !amt || isNaN(amt) || amt <= 0) return;
  const ev = S.events.find(x => x.id === eid); if (!ev) return;
  ev.deps.push({who: ME, desc, amt});
  S.notifs.unshift({icon:"💸",icls:"ni-ora",txt:`<b>Toi</b> a ajouté <b>${amt}€</b> (${desc}) sur ${ev.name}`,time:"À l'instant",unread:false});
  gainXP(15);
  showToast(`+${amt}€ ajouté · +15 XP`);
  save(); renderEvents();
}

// ─── INVITATIONS ───────────────────────────────────────────────────────────
function renderInv(ev) {
  return POTES.map(p => {
    const st = ev.invites[p] || "none";
    const btn = st==="accepted"
      ? `<button class="inv-btn inv-accepted">Confirmé ✓</button>`
      : st==="sent"
      ? `<button class="inv-btn inv-sent">Envoyé…</button>`
      : `<button class="inv-btn inv-send" onclick="sendInv(${ev.id},'${p}',event)">Inviter</button>`;
    const statusTxt = st==="accepted"?"Dans la liste":st==="sent"?"Invitation envoyée":"Pas encore invité";
    return `<div class="inv-row">
      <div class="inv-left">
        <div class="av ${AVC[p]||'agr'}">${INI(p)}</div>
        <div><div class="inv-name">${p}${p===ME?' (toi)':''}</div><div class="inv-status">${statusTxt}</div></div>
      </div>
      ${btn}
    </div>`;
  }).join('');
}

function sendInv(eid, pote, e) {
  if (e) e.stopPropagation();
  const ev = S.events.find(x => x.id === eid); if (!ev) return;
  ev.invites[pote] = "sent";
  S.notifs.unshift({icon:"✉️",icls:"ni-grn",txt:`Invitation envoyée à <b>${pote}</b> pour <b>${ev.name}</b>`,time:"À l'instant",unread:false});
  gainXP(5);
  showToast(`Invitation envoyée à ${pote} !`);
  save(); renderEvents();
}

// ─── NOTIFS ────────────────────────────────────────────────────────────────
function renderNotifs() {
  const el = document.getElementById('notif-list'); if (!el) return;
  el.innerHTML = S.notifs.slice(0,10).map(n => `
    <div class="notif-item ${n.unread?'unread':''}">
      <div class="notif-icon ${n.icls}">${n.icon}</div>
      <div style="flex:1"><div class="notif-txt">${n.txt}</div><div class="notif-time">${n.time}</div></div>
      ${n.unread ? '<div class="unread-dot"></div>' : ''}
    </div>`).join('');
  S.notifs.forEach(n => n.unread = false);
  const dot = document.getElementById('dot-notifs');
  if (dot) dot.classList.remove('show');
  save();
}

// ─── STATS ─────────────────────────────────────────────────────────────────
function renderStats() {
  const scores = POTES.map(p => ({name:p, yes:S.events.filter(e=>e.votes[p]==="yes").length})).sort((a,b)=>b.yes-a.yes);
  const trophies = ["🥇","🥈","🥉","","",""];
  document.getElementById('rank-list').innerHTML = scores.map((s,i) => {
    const pct = S.events.length ? Math.round((s.yes/S.events.length)*100) : 0;
    const bc = i===0?"#b46eff":i===1?"#7fff6e":"#ff8c00";
    return `<div class="pote-row2">
      <div class="pote-av2 ${AVC[s.name]||'agr'}">${INI(s.name)}</div>
      <div style="flex:1">
        <div style="font-size:13px;font-weight:600;color:var(--text)">${s.name}${s.name===ME?' (toi)':''} ${trophies[i]||''}</div>
        <div class="pbar" style="margin-top:4px"><div class="pbar-f" style="width:${pct}%;background:${bc}"></div></div>
      </div>
      <div style="font-size:13px;font-weight:700;color:var(--text);min-width:36px;text-align:right">${s.yes}/${S.events.length}</div>
    </div>`;
  }).join('');
  document.getElementById('m1').textContent = S.events.length;
  document.getElementById('m2').textContent = POTES.length;
  document.getElementById('m3').textContent = S.events.filter(e=>e.votes[ME]==="yes").length;
}

// ─── CRÉER ─────────────────────────────────────────────────────────────────
function addEvent() {
  const name = document.getElementById('nc-name').value.trim();
  const date = document.getElementById('nc-date').value;
  const time = document.getElementById('nc-time').value;
  const lieu = document.getElementById('nc-lieu').value.trim();
  if (!name || !date || !lieu) { showToast("Remplis le nom, la date et le lieu !"); return; }
  const votes = {}; POTES.forEach(p => votes[p]=""); votes[ME]="yes";
  const invites = {}; POTES.forEach(p => invites[p]="none"); invites[ME]="accepted";
  S.events.unshift({id: Date.now(), name, date, time: time||"22:00", lieu, vibe: S.selVibe, by: ME, votes, chat:[], deps:[], invites});
  S.notifs.unshift({icon:"🎉",icls:"ni-pur",txt:`<b>Toi</b> as créé <b>${name}</b> — invite tes potes !`,time:"À l'instant",unread:false});
  gainXP(50);
  showToast("Soirée créée ! +50 XP 🎉");
  document.getElementById('nc-name').value = '';
  document.getElementById('nc-lieu').value = '';
  save();
  goTab('events', document.querySelectorAll('.nav-btn')[0]);
}

// ─── SERVICE WORKER (notifications) ────────────────────────────────────────
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js').catch(() => {});
}

// ─── INIT ──────────────────────────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
  renderEvents();
  updateHeader();
  const unread = S.notifs.filter(n=>n.unread).length;
  const dot = document.getElementById('dot-notifs');
  if (dot && unread > 0) dot.classList.add('show');
});
